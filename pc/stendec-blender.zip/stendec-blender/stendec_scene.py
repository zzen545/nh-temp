# STENDEC 10 s Blender test (seconds 70-80): night Andes, moonlight with real shadows, volumetric cloud layer,
# Lancastrian model, glowing real (red) and believed (blue) paths, impact flash.
# Usage: blender -b -P stendec_scene.py -- <output.mp4> [frame_start frame_end] [scale%]
import bpy, json, math, os, sys
import numpy as np
from mathutils import Vector, Quaternion

D = os.path.dirname(os.path.abspath(__file__))
argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
OUT = argv[0] if argv else os.path.join(D, "stendec-blender-test.mp4")
F0 = int(argv[1]) if len(argv) > 1 else 1
F1 = int(argv[2]) if len(argv) > 2 else 300
PCT = int(argv[3]) if len(argv) > 3 else 100
S = json.load(open(os.path.join(D, "scene.json")))
MAPW, MAPH, EX, UNIT_M = S["MAPW"], S["MAPH"], S["EX"], S["UNIT_M"]
BASE = S["base"]

def B3(v):  # three.js (x, y up, z south) -> Blender (x, y north, z up)
    return Vector((v[0], -v[2], v[1]))

bpy.ops.wm.read_factory_settings(use_empty=True)
scene = bpy.context.scene

# ---------------- terrain ----------------
merc = lambda la: np.log(np.tan(np.pi / 4 + np.asarray(la) * np.pi / 360))

def load(g, name):
    return (np.fromfile(os.path.join(D, name + "_h.bin"), np.uint16).reshape(g["gh"], g["gw"]).astype(np.float32) - 500)

def bilinear(h, u, v):
    gh, gw = h.shape
    gx = np.clip(u * gw - .5, 0, gw - 1.001); gy = np.clip(v * gh - .5, 0, gh - 1.001)
    x0 = np.floor(gx).astype(int); y0 = np.floor(gy).astype(int); fx = gx - x0; fy = gy - y0
    x1 = np.minimum(x0 + 1, gw - 1); y1 = np.minimum(y0 + 1, gh - 1)
    return h[y0, x0] * (1 - fx) * (1 - fy) + h[y0, x1] * fx * (1 - fy) + h[y1, x0] * (1 - fx) * fy + h[y1, x1] * fx * fy

def terrain(name, g, step, parent=None, lift=0.0):
    h = load(g, name)
    nx, ny = g["gw"] // step, g["gh"] // step
    u = np.linspace(0, 1, nx); v = np.linspace(0, 1, ny)
    U, V = np.meshgrid(u, v)
    m = bilinear(h, U, V)
    lon = g["lon0"] + (g["lon1"] - g["lon0"]) * U
    my = merc(g["lat0"]) + (merc(g["lat1"]) - merc(g["lat0"])) * V
    if parent is not None:  # ease the inset's edges into the parent grid's heights
        pg, ph = parent
        pu = (lon - pg["lon0"]) / (pg["lon1"] - pg["lon0"])
        pv = (merc(pg["lat0"]) - my) / (merc(pg["lat0"]) - merc(pg["lat1"]))
        e = np.clip(np.minimum(np.minimum(U, 1 - U), np.minimum(V, 1 - V)) / 0.06, 0, 1)
        m = m * e + bilinear(ph, pu, pv) * (1 - e)
    x = ((lon - BASE["lon0"]) / (BASE["lon1"] - BASE["lon0"]) - .5) * MAPW
    z = ((merc(BASE["lat0"]) - my) / (merc(BASE["lat0"]) - merc(BASE["lat1"])) - .5) * MAPH
    y = np.maximum(m, 0) / UNIT_M * EX + lift
    verts = np.stack([x, -z, y], -1).reshape(-1, 3).astype(np.float32)
    idx = np.arange(nx * ny).reshape(ny, nx)
    # faces wound counter-clockwise seen from above (+Z)
    q = np.stack([idx[1:, :-1], idx[1:, 1:], idx[:-1, 1:], idx[:-1, :-1]], -1).reshape(-1, 4)
    me = bpy.data.meshes.new(name)
    me.vertices.add(len(verts)); me.vertices.foreach_set("co", verts.ravel())
    me.loops.add(q.size); me.loops.foreach_set("vertex_index", q.ravel().astype(np.int32))
    me.polygons.add(len(q)); me.polygons.foreach_set("loop_start", (np.arange(len(q)) * 4).astype(np.int32))
    try:
        me.polygons.foreach_set("loop_total", np.full(len(q), 4, np.int32))
    except Exception:
        pass
    uv = me.uv_layers.new(name="UVMap")
    uvs = np.stack([U, 1 - V], -1).reshape(-1, 2)[q.ravel()]
    uv.data.foreach_set("uv", uvs.astype(np.float32).ravel())
    me.update(calc_edges=True)
    me.polygons.foreach_set("use_smooth", np.ones(len(q), bool))
    ob = bpy.data.objects.new(name, me); scene.collection.objects.link(ob)
    mat = bpy.data.materials.new(name + "_mat"); mat.use_nodes = True
    nt = mat.node_tree; bsdf = nt.nodes["Principled BSDF"]
    img = nt.nodes.new("ShaderNodeTexImage"); img.image = bpy.data.images.load(os.path.join(D, name + "_alb.jpg"))
    img.interpolation = "Cubic"
    nt.links.new(img.outputs["Color"], bsdf.inputs["Base Color"])
    bsdf.inputs["Roughness"].default_value = 0.8
    if "Specular IOR Level" in bsdf.inputs: bsdf.inputs["Specular IOR Level"].default_value = 0.25
    me.materials.append(mat)
    return ob, (g, h)

core_ob, core_g = terrain("core", S["core"], 2)
fine_ob, _ = terrain("fine", S["fine"], 1, parent=core_g, lift=0.00015)

# ---------------- lighting / world ----------------
az, alt = math.radians(300), math.radians(38)
to_light = Vector((math.sin(az) * math.cos(alt), math.cos(az) * math.cos(alt), math.sin(alt)))
sun_d = bpy.data.lights.new("Moon", "SUN"); sun_d.energy = 3.2; sun_d.color = (0.72, 0.82, 1.0); sun_d.angle = math.radians(1.2)
sun = bpy.data.objects.new("Moon", sun_d); scene.collection.objects.link(sun)
sun.rotation_mode = "QUATERNION"; sun.rotation_quaternion = to_light.to_track_quat("Z", "Y")

world = bpy.data.worlds.new("Night"); scene.world = world; world.use_nodes = True
wn = world.node_tree; bg = wn.nodes["Background"]; bg.inputs["Color"].default_value = (0.03, 0.05, 0.11, 1); bg.inputs["Strength"].default_value = 1.6

# volumetric cloud layer
x0, z0, x1, z1, cy = S["cloudBox"]
bpy.ops.mesh.primitive_cube_add(size=1)
cloud = bpy.context.active_object; cloud.name = "Clouds"
cloud.location = ((x0 + x1) / 2, -(z0 + z1) / 2, cy); cloud.scale = (abs(x1 - x0), abs(z1 - z0), 0.05)
cm = bpy.data.materials.new("cloud"); cm.use_nodes = True; cn = cm.node_tree
cn.nodes.remove(cn.nodes["Principled BSDF"])
pv = cn.nodes.new("ShaderNodeVolumePrincipled"); pv.inputs["Color"].default_value = (0.82, 0.86, 0.95, 1)
tc = cn.nodes.new("ShaderNodeTexCoord"); mp = cn.nodes.new("ShaderNodeMapping")
mp.inputs["Scale"].default_value = (5.0, 3.0, 1.0)
nz = cn.nodes.new("ShaderNodeTexNoise"); nz.inputs["Scale"].default_value = 3.5; nz.inputs["Detail"].default_value = 8; nz.inputs["Roughness"].default_value = 0.6
ramp = cn.nodes.new("ShaderNodeValToRGB"); ramp.color_ramp.elements[0].position = 0.52; ramp.color_ramp.elements[1].position = 0.72
gz = cn.nodes.new("ShaderNodeSeparateXYZ"); gr = cn.nodes.new("ShaderNodeMath"); gr.operation = "PINGPONG"  # thin out top/bottom
gr.inputs[1].default_value = 0.5
mul = cn.nodes.new("ShaderNodeMath"); mul.operation = "MULTIPLY"
dens = cn.nodes.new("ShaderNodeMath"); dens.operation = "MULTIPLY"; dens.name = "dens"; dens.inputs[1].default_value = 6.0
cn.links.new(tc.outputs["Object"], mp.inputs["Vector"]); cn.links.new(mp.outputs[0], nz.inputs["Vector"])
cn.links.new(nz.outputs["Fac"], ramp.inputs["Fac"])
cn.links.new(tc.outputs["Generated"], gz.inputs[0]); cn.links.new(gz.outputs["Z"], gr.inputs[0])
cn.links.new(ramp.outputs["Color"], mul.inputs[0]); cn.links.new(gr.outputs[0], mul.inputs[1])
cn.links.new(mul.outputs[0], dens.inputs[0]); cn.links.new(dens.outputs[0], pv.inputs["Density"])
cn.links.new(pv.outputs[0], cn.nodes["Material Output"].inputs["Volume"])
cloud.data.materials.append(cm)

# ---------------- materials ----------------
def emis(name, col, strength):
    m = bpy.data.materials.new(name); m.use_nodes = True; t = m.node_tree
    t.nodes.remove(t.nodes["Principled BSDF"])
    e = t.nodes.new("ShaderNodeEmission"); e.inputs["Color"].default_value = (*col, 1); e.inputs["Strength"].default_value = strength
    t.links.new(e.outputs[0], t.nodes["Material Output"].inputs["Surface"]); return m
metal = bpy.data.materials.new("metal"); metal.use_nodes = True
mb = metal.node_tree.nodes["Principled BSDF"]; mb.inputs["Base Color"].default_value = (0.78, 0.8, 0.86, 1)
mb.inputs["Metallic"].default_value = 0.7; mb.inputs["Roughness"].default_value = 0.3
darkm = bpy.data.materials.new("dark"); darkm.use_nodes = True; darkm.node_tree.nodes["Principled BSDF"].inputs["Base Color"].default_value = (0.05, 0.06, 0.08, 1)
red_e, green_e, white_e = emis("navR", (1, .15, .15), 30), emis("navG", (.2, 1, .4), 30), emis("navW", (1, 1, 1), 30)
ghost_m = emis("ghost", (0.45, 0.7, 1.0), 6)

# ---------------- aircraft (stylised Avro Lancastrian, model units = metres, +X forward) ----------------
def add(prim, mat, loc=(0, 0, 0), rot=(0, 0, 0), scale=(1, 1, 1), **kw):
    getattr(bpy.ops.mesh, prim)(location=loc, rotation=rot, **kw)
    o = bpy.context.active_object; o.scale = scale; o.data.materials.append(mat)
    bpy.ops.object.shade_smooth(); return o
def plane(mat, lights=True):
    parts = [
        add("primitive_cylinder_add", mat, (0, 0, 0), (0, math.pi / 2, 0), vertices=24, radius=1.2, depth=21),
        add("primitive_cone_add", mat, (11.6, 0, 0), (0, math.pi / 2, 0), vertices=24, radius1=1.2, depth=3.2),
        add("primitive_cube_add", mat, (1.6, 0, -0.3), scale=(2.1, 15.5, 0.22), size=2),
        add("primitive_cube_add", mat, (-9.6, 0, 0.2), scale=(1.3, 5.0, 0.15), size=2),
        add("primitive_cube_add", mat, (-9.8, 5, 1.4), scale=(1.2, 0.15, 1.6), size=2),
        add("primitive_cube_add", mat, (-9.8, -5, 1.4), scale=(1.2, 0.15, 1.6), size=2),
    ]
    for yy in (-10.5, -4.6, 4.6, 10.5):
        parts.append(add("primitive_cylinder_add", mat, (3.3, yy, -0.35), (0, math.pi / 2, 0), vertices=16, radius=0.72, depth=5.2))
    if lights:
        parts.append(add("primitive_cube_add", darkm, (9.4, 0, 0.75), scale=(1.0, 0.8, 0.3), size=2))
        parts.append(add("primitive_uv_sphere_add", red_e, (1.6, 15.6, -0.2), radius=0.6))   # port (left) wing = +Y when flying +X
        parts.append(add("primitive_uv_sphere_add", green_e, (1.6, -15.6, -0.2), radius=0.6))
        parts.append(add("primitive_uv_sphere_add", white_e, (-10.8, 0, 0.4), radius=0.5))
    bpy.ops.object.select_all(action="DESELECT")
    for p in parts: p.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]; bpy.ops.object.join()
    o = bpy.context.active_object; o.rotation_mode = "QUATERNION"; return o
star = plane(metal); star.name = "StarDust"
ghost = plane(ghost_m, lights=False); ghost.name = "Believed"
for o in (star, ghost): o.visible_shadow = True

# ---------------- glowing paths ----------------
def path(name, pts, col, r):
    cu = bpy.data.curves.new(name, "CURVE"); cu.dimensions = "3D"; cu.bevel_depth = r; cu.bevel_resolution = 3
    sp = cu.splines.new("POLY"); sp.points.add(len(pts) - 1)
    for i, p in enumerate(pts): b = B3(p); sp.points[i].co = (b.x, b.y, b.z, 1)
    cu.bevel_factor_mapping_end = "SPLINE"
    o = bpy.data.objects.new(name, cu); scene.collection.objects.link(o); cu.materials.append(emis(name + "_m", col, 12))
    o.visible_shadow = False; return o
desc = path("RealPath", S["desc"], (1.0, 0.25, 0.18), 0.0035)
bel = path("BelievedPath", S["bel"], (0.4, 0.65, 1.0), 0.0035)

# impact flash
bpy.ops.mesh.primitive_uv_sphere_add(radius=1, location=B3(S["crash"]))
flash = bpy.context.active_object; flash.data.materials.append(emis("flash", (1, .85, .65), 40)); flash.visible_shadow = False
fl_d = bpy.data.lights.new("FlashLight", "POINT"); fl_d.color = (1, .8, .6)
fl = bpy.data.objects.new("FlashLight", fl_d); fl.location = B3(S["crash"]) + Vector((0, 0, 0.02)); scene.collection.objects.link(fl)

# ---------------- camera + animation ----------------
cd = bpy.data.cameras.new("Cam"); cd.sensor_fit = "VERTICAL"; cd.angle_y = math.radians(S["fov"]); cd.clip_start = 0.002; cd.clip_end = 120
cam = bpy.data.objects.new("Cam", cd); scene.collection.objects.link(cam); scene.camera = cam; cam.rotation_mode = "QUATERNION"
fx = Vector((1, 0, 0))
dens_node = cn.nodes["dens"]
for i, fr in enumerate(S["frames"]):
    f = i + 1
    p = B3(fr["cam"]); look = B3(fr["look"])
    cam.location = p; cam.rotation_quaternion = (look - p).to_track_quat("-Z", "Y")
    cam.keyframe_insert("location", frame=f); cam.keyframe_insert("rotation_quaternion", frame=f)
    s = fr["span"] / 31
    star.location = B3(fr["plane"]); star.rotation_quaternion = fx.rotation_difference(B3(fr["pdir"]).normalized())
    star.scale = (s, s, s) if fr["planeOn"] else (0, 0, 0)
    for k in ("location", "rotation_quaternion", "scale"): star.keyframe_insert(k, frame=f)
    gs = s if fr["ghostOp"] > 0.05 else 0
    ghost.location = B3(fr["ghost"]); ghost.rotation_quaternion = fx.rotation_difference(B3(fr["gdir"]).normalized()); ghost.scale = (gs, gs, gs)
    for k in ("location", "rotation_quaternion", "scale"): ghost.keyframe_insert(k, frame=f)
    desc.data.bevel_factor_end = max(fr["desc"], 0.0005); desc.data.keyframe_insert("bevel_factor_end", frame=f)
    bel.data.bevel_factor_end = max(fr["bel"], 0.0005) if fr["ghostOp"] > 0 else 0.0005; bel.data.keyframe_insert("bevel_factor_end", frame=f)
    k = fr["flash"]; r = 0.0005 + (1.2 - k) * 0.06 * (k > 0)
    flash.scale = (r, r, r) if k > 0 else (0, 0, 0); flash.keyframe_insert("scale", frame=f)
    fl_d.energy = 0.6 * k; fl_d.keyframe_insert("energy", frame=f)
    dens_node.inputs[1].default_value = 6.0 * fr["cloud"]; dens_node.inputs[1].keyframe_insert("default_value", frame=f)
for o in (cam, star, ghost):
    if o.animation_data and o.animation_data.action:
        try:
            for fc in o.animation_data.action.fcurves:
                for kp in fc.keyframe_points: kp.interpolation = "LINEAR"
        except AttributeError:
            pass

# ---------------- render settings ----------------
engines = [e.identifier for e in bpy.types.RenderSettings.bl_rna.properties["engine"].enum_items]
scene.render.engine = "BLENDER_EEVEE_NEXT" if "BLENDER_EEVEE_NEXT" in engines else "BLENDER_EEVEE"
ee = scene.eevee
for attr, val in [("taa_render_samples", 64), ("use_shadows", True), ("use_raytracing", True), ("volumetric_tile_size", "4"),
                  ("volumetric_samples", 64), ("volumetric_end", 25.0), ("use_gtao", True), ("use_soft_shadows", True), ("use_bloom", True),
                  ("bloom_intensity", 0.08), ("shadow_cube_size", "2048"), ("shadow_cascade_size", "4096"), ("use_volumetric_shadows", True)]:
    try: setattr(ee, attr, val)
    except Exception: pass
if os.environ.get("STENDEC_ENGINE") == "CYCLES":  # preview on machines without a GPU
    scene.render.engine = "CYCLES"; scene.cycles.samples = 12; scene.cycles.device = "CPU"
scene.render.resolution_x, scene.render.resolution_y, scene.render.resolution_percentage = 1080, 1920, PCT
scene.render.fps = 30; scene.frame_start, scene.frame_end = F0, F1
try:
    scene.view_settings.view_transform = "AgX"; scene.view_settings.look = "AgX - Medium High Contrast"
except Exception:
    scene.view_settings.view_transform = "Filmic"
scene.view_settings.exposure = 0.6
# glow for the emissive paths/lights (compositor glare); Blender 5 uses a compositing node group, 4.x scene.node_tree
def glare_node(ct):
    gl = ct.nodes.new("CompositorNodeGlare")
    types = [e.identifier for e in gl.bl_rna.properties["glare_type"].enum_items] if "glare_type" in gl.bl_rna.properties else []
    if types: gl.glare_type = "BLOOM" if "BLOOM" in types else "FOG_GLOW"
    for k, v in (("quality", "HIGH"), ("threshold", 1.2), ("size", 7)):
        try: setattr(gl, k, v)
        except Exception: pass
    if "Type" in gl.inputs:
        try: gl.inputs["Type"].default_value = "Bloom"
        except Exception: pass
    if "Threshold" in gl.inputs: gl.inputs["Threshold"].default_value = 1.2
    return gl
try:
    if hasattr(scene, "compositing_node_group"):
        ct = bpy.data.node_groups.new("Comp", "CompositorNodeTree"); scene.compositing_node_group = ct
        rl = ct.nodes.new("CompositorNodeRLayers"); out = ct.nodes.new("NodeGroupOutput")
        ct.interface.new_socket(name="Image", in_out="OUTPUT", socket_type="NodeSocketColor")
        gl = glare_node(ct); ct.links.new(rl.outputs["Image"], gl.inputs["Image"]); ct.links.new(gl.outputs["Image"], out.inputs[0])
    else:
        scene.use_nodes = True; ct = scene.node_tree
        gl = glare_node(ct); ct.links.new(ct.nodes["Render Layers"].outputs["Image"], gl.inputs["Image"]); ct.links.new(gl.outputs["Image"], ct.nodes["Composite"].inputs["Image"])
    print("glare ok")
except Exception as e:
    print("compositor skipped:", e)
if OUT.lower().endswith(".mp4"):
    try:
        scene.render.image_settings.media_type = "VIDEO"
    except Exception:
        pass
    scene.render.image_settings.file_format = "FFMPEG"
    scene.render.ffmpeg.format = "MPEG4"; scene.render.ffmpeg.codec = "H264"; scene.render.ffmpeg.constant_rate_factor = "HIGH"
else:
    scene.render.image_settings.file_format = "PNG"
scene.render.filepath = OUT
print("SCENE READY", scene.render.engine, F0, F1)
if "--norender" not in argv:
    import time
    t0 = time.time(); bpy.ops.render.render(animation=True)
    print("RENDER DONE frames=%d seconds=%.1f per_frame=%.2f" % (F1 - F0 + 1, time.time() - t0, (time.time() - t0) / (F1 - F0 + 1)))
