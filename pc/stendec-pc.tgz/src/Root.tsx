import { Composition } from "remotion";
import { Test3D } from "./Test3D";
import { Main, DURATION } from "./Main";
import "@fontsource/cormorant-garamond/600.css";
import "@fontsource/cormorant-garamond/600-italic.css";
import "@fontsource/ibm-plex-mono/500.css";
import "@fontsource/inter/600.css";
export const Root = () => (
  <>
    <Composition id="Test3D" component={Test3D} width={1080} height={1920} fps={30} durationInFrames={300} />
    <Composition id="Main" component={Main} width={1080} height={1920} fps={30} durationInFrames={Math.round(DURATION * 30)} />
    <Composition id="MainHQ" component={Main} width={1080} height={1920} fps={30} durationInFrames={Math.round(DURATION * 30)} defaultProps={{ hq: true }} />
  </>
);
