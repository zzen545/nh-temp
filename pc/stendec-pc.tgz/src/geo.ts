import B from "./base.json";
import Cc from "./core.json";

// world space: base map spans MAPW x MAPH units (x = east, z = south), y = up
export const MAPW = 30, MAPH = 15, EX = 2.6, UNIT_M = 52700;
const merc = (lat: number) => Math.log(Math.tan(Math.PI / 4 + (lat * Math.PI) / 360));
// fractional position (0..1) inside a mercator-aligned box
const frac = (b: { lon0: number; lon1: number; lat0: number; lat1: number }, lon: number, lat: number) =>
  [(lon - b.lon0) / (b.lon1 - b.lon0), (merc(b.lat0) - merc(lat)) / (merc(b.lat0) - merc(b.lat1))];
export const lonLatToXZ = (lon: number, lat: number): [number, number] => {
  const [u, v] = frac(B, lon, lat);
  return [(u - 0.5) * MAPW, (v - 0.5) * MAPH];
};
export const boxXZ = (b: typeof Cc) => {
  const [x0, z0] = lonLatToXZ(b.lon0, b.lat0), [x1, z1] = lonLatToXZ(b.lon1, b.lat1);
  return { x0, z0, x1, z1 };
};

type Grid = { h: Uint16Array; gw: number; gh: number; b: typeof Cc };
const grids: Grid[] = [];
export const addGrid = (g: Grid) => grids.unshift(g); // later = more detailed, checked first
const sample = (g: Grid, u: number, v: number) => {
  const gx = u * g.gw - 0.5, gy = v * g.gh - 0.5;
  const x0 = Math.max(0, Math.min(g.gw - 2, Math.floor(gx))), y0 = Math.max(0, Math.min(g.gh - 2, Math.floor(gy)));
  const fx = Math.min(1, Math.max(0, gx - x0)), fy = Math.min(1, Math.max(0, gy - y0));
  const at = (x: number, y: number) => g.h[y * g.gw + x] - 500;
  return at(x0, y0) * (1 - fx) * (1 - fy) + at(x0 + 1, y0) * fx * (1 - fy) + at(x0, y0 + 1) * (1 - fx) * fy + at(x0 + 1, y0 + 1) * fx * fy;
};
export const heightAt = (lon: number, lat: number) => {
  for (const g of grids) {
    const [u, v] = frac(g.b, lon, lat);
    if (u >= 0 && u <= 1 && v >= 0 && v <= 1) return sample(g, u, v);
  }
  return 0;
};
export const metersToY = (m: number) => (Math.max(m, 0) / UNIT_M) * EX;
export const world = (lon: number, lat: number, altM?: number): [number, number, number] => {
  const [x, z] = lonLatToXZ(lon, lat);
  return [x, metersToY(altM ?? heightAt(lon, lat)), z];
};
export { B as BASE, Cc as CORE, frac, sample };
