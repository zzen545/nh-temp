import React, { useEffect, useMemo, useState } from "react";
import { AbsoluteFill, Audio, continueRender, delayRender, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { ThreeCanvas } from "@remotion/three";
import { useThree } from "@react-three/fiber";
import * as THREE from "three";
import FINE from "./fine.json";
import { BASE, CORE, EX, UNIT_M, addGrid, boxXZ, frac, sample, world, heightAt, lonLatToXZ, metersToY } from "./geo";

const SERIF = "'Cormorant Garamond', serif";
const MONO = "'IBM Plex Mono', monospace";
const AMBER = "#ffb547";
const RED = "#ff5a4a";
const BLUE = "#79b2ff";
const FOV = 36;
export const DURATION = 99.6;
const clamp01 = (x: number) => Math.max(0, Math.min(1, x));
const smooth = (x: number) => { const c = clamp01(x); return c * c * (3 - 2 * c); };
const win = (t: number, a: number, b: number, d = 0.5) => Math.min(smooth((t - a) / d), smooth((b - t) / d));
const lerp = THREE.MathUtils.lerp;

// ---------- data ----------
type Grid = { h: Uint16Array; gw: number; gh: number; b: typeof CORE };
type Assets = { base: Grid; core: Grid; baseTex: THREE.Texture; coreTex: THREE.Texture; fine?: Grid; fineTex?: THREE.Texture };
const loadTex = (f: string) => new Promise<THREE.Texture>((res) => new THREE.TextureLoader().load(staticFile(f), (t) => {
  t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 16; t.generateMipmaps = true; t.minFilter = THREE.LinearMipmapLinearFilter; res(t);
}));
const useAssets = (hq: boolean) => {
  const [h] = useState(() => delayRender("terrain"));
  const [state, set] = useState<Assets | null>(null);
  useEffect(() => {
    Promise.all([
      fetch(staticFile("base_h.bin")).then((r) => r.arrayBuffer()),
      fetch(staticFile("core_h.bin")).then((r) => r.arrayBuffer()),
      loadTex("base_tex.jpg"), loadTex("core_tex.jpg"),
      hq ? fetch(staticFile("fine_h.bin")).then((r) => r.arrayBuffer()) : Promise.resolve(null),
      hq ? loadTex("fine_tex.jpg") : Promise.resolve(undefined),
    ]).then(([bh, ch, baseTex, coreTex, fh, fineTex]) => {
      const base = { h: new Uint16Array(bh), gw: BASE.gw, gh: BASE.gh, b: BASE as typeof CORE };
      const core = { h: new Uint16Array(ch), gw: CORE.gw, gh: CORE.gh, b: CORE };
      addGrid(base); addGrid(core);
      const fine = fh ? { h: new Uint16Array(fh), gw: FINE.gw, gh: FINE.gh, b: FINE as typeof CORE } : undefined;
      if (fine) addGrid(fine);
      set({ base, core, baseTex, coreTex, fine, fineTex });
      continueRender(h);
    });
  }, [h, hq]);
  return state;
};

const merc = (la: number) => Math.log(Math.tan(Math.PI / 4 + (la * Math.PI) / 360));
const makeTerrain = (g: Grid, step: number, base?: Grid) => {
  const { x0, z0, x1, z1 } = boxXZ(g.b);
  const sx = Math.floor(g.gw / step) - 1, sy = Math.floor(g.gh / step) - 1;
  const geo = new THREE.PlaneGeometry(x1 - x0, z1 - z0, sx, sy);
  geo.rotateX(-Math.PI / 2);
  geo.translate((x0 + x1) / 2, 0, (z0 + z1) / 2);
  const pos = geo.attributes.position as THREE.BufferAttribute;
  for (let j = 0; j <= sy; j++) for (let i = 0; i <= sx; i++) {
    const u = i / sx, v = j / sy;
    let m = sample(g, u, v);
    if (base) {
      const lon = g.b.lon0 + (g.b.lon1 - g.b.lon0) * u;
      const yv = merc(g.b.lat0) + (merc(g.b.lat1) - merc(g.b.lat0)) * v;
      const lat = (2 * Math.atan(Math.exp(yv)) - Math.PI / 2) * 180 / Math.PI;
      const [bu, bv] = frac(base.b, lon, lat);
      const e = clamp01(Math.min(u, 1 - u, v, 1 - v) / 0.06);
      m = m * e + sample(base, bu, bv) * (1 - e);
    }
    pos.setY(j * (sx + 1) + i, (Math.max(m, 0) / UNIT_M) * EX);
  }
  geo.computeVertexNormals();
  return geo;
};

// ---------- aircraft (stylised Avro Lancastrian) ----------
const Plane: React.FC<{ pos: THREE.Vector3; dir: THREE.Vector3; t: number; span: number; op?: number; tint?: string; ghost?: boolean }> = ({ pos, dir, t, span, op = 1, tint = "#d9dee8", ghost }) => {
  if (op <= 0.01) return null;
  const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(1, 0, 0), dir.clone().normalize());
  const s = span / 31;
  const metal = ghost
    ? <meshBasicMaterial color={tint} transparent opacity={0.9 * op} depthWrite={false} fog={false} />
    : <meshStandardMaterial color={tint} metalness={0.55} roughness={0.35} transparent={op < 1} opacity={op} />;
  const dark = <meshStandardMaterial color="#3a4152" metalness={0.3} roughness={0.6} transparent={op < 1} opacity={op} />;
  const blink = Math.sin(t * 9) > 0.2 ? 1 : 0.15;
  return (
    <group position={pos} quaternion={q} scale={[s, s, s]}>
      <mesh rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[1.25, 0.8, 21, 14]} />{metal}</mesh>
      <mesh position={[11.2, 0, 0]} rotation={[0, 0, -Math.PI / 2]}><coneGeometry args={[1.25, 3.2, 14]} />{metal}</mesh>
      {!ghost && <mesh position={[9.4, 0.75, 0]}><boxGeometry args={[2.0, 0.6, 1.6]} />{dark}</mesh>}
      <mesh position={[1.6, -0.3, 0]}><boxGeometry args={[4.2, 0.45, 31]} />{metal}</mesh>
      {[-10.5, -4.6, 4.6, 10.5].map((z) => (
        <group key={z} position={[3.3, -0.35, z]}>
          <mesh rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.75, 0.6, 5.2, 10]} />{metal}</mesh>
          {!ghost && (
            <mesh position={[2.75, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
              <circleGeometry args={[2.2, 20]} />
              <meshBasicMaterial color="#cfd8ea" transparent opacity={0.18 * op} side={THREE.DoubleSide} depthWrite={false} />
            </mesh>
          )}
        </group>
      ))}
      <mesh position={[-9.6, 0.2, 0]}><boxGeometry args={[2.6, 0.3, 10]} />{metal}</mesh>
      {[-5, 5].map((z) => <mesh key={z} position={[-9.8, 1.4, z]}><boxGeometry args={[2.4, 3.2, 0.3]} />{metal}</mesh>)}
      {!ghost && <>
        <mesh position={[1.6, -0.2, -15.6]}><sphereGeometry args={[0.6, 8, 8]} /><meshBasicMaterial color="#ff3b3b" transparent opacity={op} /></mesh>
        <mesh position={[1.6, -0.2, 15.6]}><sphereGeometry args={[0.6, 8, 8]} /><meshBasicMaterial color="#3bff7a" transparent opacity={op} /></mesh>
        <mesh position={[-10.8, 0.4, 0]}><sphereGeometry args={[0.5, 8, 8]} /><meshBasicMaterial color="#ffffff" transparent opacity={blink * op} /></mesh>
      </>}
    </group>
  );
};

// ---------- geography ----------
const CRUISE = 7300;
const BA: [number, number] = [-58.54, -34.66];
const WAY: [number, number][] = [BA, [-61.0, -34.35], [-63.5, -33.95], [-66.0, -33.5], [-67.6, -33.25], [-68.6, -33.25], [-69.4, -33.33]];
const CRASH: [number, number] = [-69.79, -33.362];
const ENGINE: [number, number] = [-69.761, -33.371];
const BELIEVED: [number, number][] = [[-70.12, -33.40], [-70.4, -33.43], [-70.66, -33.45]];

const glowTex = (() => {
  const c = document.createElement("canvas"); c.width = c.height = 128;
  const x = c.getContext("2d")!; const g = x.createRadialGradient(64, 64, 0, 64, 64, 64);
  g.addColorStop(0, "rgba(255,255,255,.9)"); g.addColorStop(0.3, "rgba(160,200,255,.35)"); g.addColorStop(1, "rgba(80,140,255,0)");
  x.fillStyle = g; x.fillRect(0, 0, 128, 128);
  return new THREE.CanvasTexture(c);
})();
// seeded random
const rng = (seed: number) => () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
const cloudTex = (() => {
  const c = document.createElement("canvas"); c.width = c.height = 1024;
  const x = c.getContext("2d")!; const r = rng(7);
  for (let i = 0; i < 520; i++) {
    const cx = r() * 1024, cy = r() * 1024, rad = 30 + r() * 120;
    for (const [ox, oy] of [[0, 0], [1024, 0], [-1024, 0], [0, 1024], [0, -1024]]) {
      const g = x.createRadialGradient(cx + ox, cy + oy, 0, cx + ox, cy + oy, rad);
      g.addColorStop(0, `rgba(215,225,245,${0.10 + r() * 0.08})`); g.addColorStop(1, "rgba(215,225,245,0)");
      x.fillStyle = g; x.fillRect(cx + ox - rad, cy + oy - rad, rad * 2, rad * 2);
    }
  }
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; return t;
})();

// ---------- timeline ----------
// monotone cubic interpolation over keyframes (smooth, no overshoot)
const mono = (ts: number[], ys: number[], t: number) => {
  const n = ts.length;
  if (t <= ts[0]) return ys[0];
  if (t >= ts[n - 1]) return ys[n - 1];
  const hs = ts.slice(1).map((x, i) => x - ts[i]);
  const d = hs.map((h, i) => (ys[i + 1] - ys[i]) / h);
  const m = ys.map((_, i) => {
    if (i === 0 || i === n - 1 || d[i - 1] * d[i] <= 0) return 0;
    const w1 = 2 * hs[i] + hs[i - 1], w2 = hs[i] + 2 * hs[i - 1];
    return (w1 + w2) / (w1 / d[i - 1] + w2 / d[i]);
  });
  let k = 0; while (t > ts[k + 1]) k++;
  const h = ts[k + 1] - ts[k], s = (t - ts[k]) / h;
  const h00 = 2 * s ** 3 - 3 * s ** 2 + 1, h10 = s ** 3 - 2 * s ** 2 + s, h01 = -2 * s ** 3 + 3 * s ** 2, h11 = s ** 3 - s ** 2;
  return h00 * ys[k] + h10 * h * m[k] + h01 * ys[k + 1] + h11 * h * m[k + 1];
};
// camera keys: t, lon, lat, target alt m, dist, pitch, yaw  (yaw 90 = camera east looking west, 0 = south looking north)
// t, lon, lat, alt m, dist, pitch, yaw, follow (0..1 = how much the target tracks the aircraft), lead (deg west of the aircraft)
const CAM: number[][] = [
  [0.0, -69.7, -33.2, 0, 10.5, 64, 140, 0, 0],
  [6.6, -69.3, -33.3, 0, 8.6, 56, 132, 0, 0],
  [10.0, -60.4, -34.4, 0, 6.6, 50, 120, 0.6, 0.2],
  [14.0, -64.6, -33.7, 0, 7.2, 46, 112, 0.6, 0.4],
  [19.0, -68.2, -33.1, 5000, 5.0, 46, 105, 0.85, 0.2],
  [22.6, -68.7, -33.2, 6500, 4.4, 50, 104, 1, 0.12],
  [28.0, -69.25, -33.28, 6500, 4.0, 52, 104, 1, 0.1],
  [34.5, -69.45, -33.3, 6500, 3.5, 52, 108, 1, 0.1],
  [41.5, -69.6, -33.33, 5500, 3.6, 52, 120, 0.6, 0.1],
  [45.0, -69.45, -33.3, 3000, 5.6, 55, 162, 0, 0],
  [49.6, -69.45, -33.3, 3000, 6.0, 58, 170, 0, 0],
  [54.6, -69.775, -33.366, 5200, 0.95, 36, 128, 0, 0],
  [58.3, -69.775, -33.366, 5200, 0.8, 33, 112, 0, 0],
  [61.5, -69.1, -33.29, 6600, 1.7, 32, 150, 1, 0.05],
  [68.2, -69.38, -33.32, 6600, 1.7, 34, 140, 1, 0.05],
  [71.4, -69.75, -33.37, 5000, 7.5, 64, 100, 0, 0],
  [73.4, -69.76, -33.37, 5000, 7.0, 62, 104, 0, 0],
  [74.8, -69.79, -33.365, 5600, 1.3, 38, 118, 0, 0],
  [79.0, -69.78, -33.366, 5300, 0.72, 40, 132, 0, 0],
  [85.0, -69.775, -33.368, 5000, 0.62, 46, 158, 0, 0],
  [92.0, -69.7, -33.32, 3000, 3.8, 50, 196, 0, 0],
  [99.6, -69.6, -33.3, 2000, 6.2, 60, 212, 0, 0],
];
const camAt = (t: number, plane: THREE.Vector3 | null) => {
  const ts = CAM.map((k) => k[0]);
  const v = [1, 2, 3, 4, 5, 6, 7, 8].map((i) => mono(ts, CAM.map((k) => k[i]), t));
  const [lon, lat, alt, dist, pitchD, yawD, follow, lead] = v;
  const [x, z] = lonLatToXZ(lon, lat);
  const target = new THREE.Vector3(x, metersToY(alt), z);
  if (plane && follow > 0) {
    const [lx] = lonLatToXZ(-60 - lead, -33.3), [l0] = lonLatToXZ(-60, -33.3);
    target.x = lerp(target.x, plane.x + (lx - l0), follow);
    target.z = lerp(target.z, plane.z, follow);
  }
  const pitch = THREE.MathUtils.degToRad(pitchD), yaw = THREE.MathUtils.degToRad(yawD);
  const pos = new THREE.Vector3(target.x + Math.sin(yaw) * Math.cos(pitch) * dist, target.y + Math.sin(pitch) * dist, target.z + Math.cos(yaw) * Math.cos(pitch) * dist);
  return { pos, look: target, dist };
};
// aircraft longitude on the main route over time
const PLANE1: number[][] = [[7.4, -58.54], [14.0, -64.0], [19.0, -67.6], [22.6, -68.75], [34.0, -69.3], [41.6, -69.4]];
const PLANE2: number[][] = [[58.6, -68.9], [70.3, -69.4]];
const lonAt = (keys: number[][], t: number) => {
  for (let i = 0; i < keys.length - 1; i++) if (t <= keys[i + 1][0]) {
    const s = clamp01((t - keys[i][0]) / (keys[i + 1][0] - keys[i][0]));
    return lerp(keys[i][1], keys[i + 1][1], s);
  }
  return keys[keys.length - 1][1];
};

const CameraRig: React.FC<{ cam: { pos: THREE.Vector3; look: THREE.Vector3 } }> = ({ cam }) => {
  const { camera } = useThree();
  camera.position.copy(cam.pos);
  camera.lookAt(cam.look);
  (camera as THREE.PerspectiveCamera).fov = FOV;
  (camera as THREE.PerspectiveCamera).updateProjectionMatrix();
  return null;
};

// ---------- narration ----------
type Cap = [number, string, string?, string?];
const CAPS: Cap[] = [
  [0.0, "In 1947, a plane sent ", "one strange word…"],
  [4.8, "…and then vanished for ", "fifty years."],
  [7.4, "It was called ", "Star Dust."],
  [9.4, "An airliner flying from Buenos Aires to Santiago, with ", "eleven people", " on board."],
  [14.3, "Between them and Santiago stood ", "the Andes."],
  [17.0, "Peaks almost ", "seven kilometres", " high."],
  [19.5, "So the plane climbed to ", "24,000 feet."],
  [22.8, "At 5:41 in the evening, the radio operator sent a ", "Morse message."],
  [27.0, "Arriving in ", "four minutes."],
  [28.8, "Then one ", "last word:"],
  [34.8, "Santiago didn't understand it, so they ", "asked again."],
  [38.2, "", "STENDEC.", " Twice."],
  [40.8, "Then, ", "silence."],
  [42.9, "Search planes found nothing. ", "No wreckage, no trace."],
  [46.6, "People blamed sabotage… even ", "UFOs."],
  [49.7, "Then, in ", "1998", ", two climbers on Mount Tupungato found something in the ice:"],
  [55.0, "a Rolls-Royce engine. ", "From Star Dust."],
  [58.4, "So ", "what happened?"],
  [59.8, "High above the clouds, a powerful wind was blowing ", "straight at them."],
  [63.8, "Today we call it the ", "jet stream."],
  [65.8, "Back then, pilots ", "barely understood it."],
  [68.4, "The wind ", "slowed them down."],
  [70.3, "The crew thought they had already ", "crossed the mountains,"],
  [72.5, "so they began to descend… ", "straight into the glacier."],
  [76.0, "The crash set off an avalanche that ", "buried the plane", " in snow."],
  [79.8, "For fifty years, the glacier slowly carried it ", "down the mountain,"],
  [83.2, "until the ice ", "gave it back."],
  [85.8, "Star Dust was ", "never really lost."],
  [87.7, "It was frozen ", "inside the mountain."],
  [90.2, "Sounds fake. ", "It's real."],
  [92.8, "And ", "STENDEC?"],
  [95.1, "Nobody knows ", "what it meant."],
  [96.8, "", "What do you think?"],
];
const Narration: React.FC<{ t: number }> = ({ t }) => {
  let i = -1; for (let k = 0; k < CAPS.length; k++) if (t >= CAPS[k][0]) i = k;
  if (i < 0) return null;
  const [s, a, b, c] = CAPS[i];
  const e = i + 1 < CAPS.length ? CAPS[i + 1][0] : DURATION + 1;
  const op = Math.min(smooth((t - s) / 0.22), smooth((e - t) / 0.18));
  const y = (1 - smooth((t - s) / 0.35)) * 14;
  return (
    <div style={{ position: "absolute", top: 1290, left: 80, right: 80, textAlign: "center", fontFamily: SERIF, fontWeight: 600, fontSize: 60, lineHeight: 1.12,
      color: "#f4f6fb", textShadow: "0 2px 18px rgba(0,0,0,.75)", opacity: op, transform: `translateY(${y}px)` }}>
      {a}{b && <span style={{ color: AMBER, fontStyle: "italic" }}>{b}</span>}{c}
    </div>
  );
};

// ---------- overlay pieces ----------
const safe = (y: number) => Math.min(smooth((y - 470) / 40), smooth((1180 - y) / 50));
const Label: React.FC<{ p: { x: number; y: number; vis: boolean }; title: string; sub?: string; op: number; color?: string; left?: boolean }> = ({ p, title, sub, op, color = "#dbe7ff", left }) => {
  const o = op * safe(p.y) * (p.vis ? 1 : 0);
  if (o <= 0.01) return null;
  return (
    <div style={{ position: "absolute", left: p.x, top: p.y, opacity: o, transform: "translate(-7px,-7px)" }}>
      <div style={{ width: 14, height: 14, borderRadius: 7, background: color, boxShadow: `0 0 14px ${color}` }} />
      <div style={{ position: "absolute", [left ? "right" : "left"]: left ? 8 : 24, top: -7, textAlign: left ? "right" : "left", whiteSpace: "nowrap", fontFamily: MONO, fontWeight: 500, fontSize: 23, letterSpacing: 4, color,
        textShadow: "0 0 8px rgba(0,0,0,.95), 0 0 2px #000" }}>
        {title}
        {sub && <div style={{ fontSize: 18, letterSpacing: 2, opacity: 0.85, marginTop: 4 }}>{sub}</div>}
      </div>
    </div>
  );
};
const MORSE: Record<string, string> = { S: "···", T: "−", E: "·", N: "−·", D: "−··", C: "−·−·" };
const WORD = "STENDEC".split("");
const Stendec: React.FC<{ shown: number; op: number; flash?: number; suffix?: string }> = ({ shown, op, flash = 0, suffix }) => (
  <div style={{ position: "absolute", top: 300, left: 0, right: 0, display: "flex", justifyContent: "center", gap: 22, opacity: op }}>
    {WORD.map((L, i) => (
      <div key={i} style={{ textAlign: "center", opacity: i < shown ? 1 : 0.1 }}>
        <div style={{ fontFamily: MONO, fontSize: 22, color: AMBER, letterSpacing: 2, height: 28 }}>{MORSE[L]}</div>
        <div style={{ fontFamily: SERIF, fontWeight: 600, fontSize: 96, lineHeight: 1.05, color: "#fff", textShadow: `0 0 ${18 + flash * 30}px ${AMBER}` }}>{L}</div>
      </div>
    ))}
    {suffix && <div style={{ fontFamily: SERIF, fontWeight: 600, fontStyle: "italic", fontSize: 96, color: AMBER, alignSelf: "flex-end", lineHeight: 1.05 }}>{suffix}</div>}
  </div>
);
const TopLine: React.FC<{ text: string; op: number; color?: string; top?: number; size?: number }> = ({ text, op, color = "#a8c2ee", top = 150, size = 21 }) =>
  op > 0.01 ? <div style={{ position: "absolute", top, left: 0, right: 0, textAlign: "center", fontFamily: MONO, fontSize: size, letterSpacing: 6, color, opacity: op, textShadow: "0 0 8px rgba(0,0,0,.9)" }}>{text}</div> : null;
const Year: React.FC<{ y: number; op: number }> = ({ y, op }) =>
  op > 0.01 ? <div style={{ position: "absolute", top: 270, left: 0, right: 0, textAlign: "center", fontFamily: SERIF, fontWeight: 600, fontSize: 150, letterSpacing: 4, color: "#fff", opacity: op, textShadow: `0 0 30px rgba(120,170,255,.6)` }}>{Math.round(y)}</div> : null;

// letter reveal times (from the VO's spelled-out letters)
const L1 = [2.6, 2.85, 3.1, 3.35, 3.6, 3.85, 4.1];
const L2 = [31.24, 31.5, 31.88, 32.46, 32.88, 33.34, 33.6];
const L3 = [92.86, 93.18, 93.44, 93.68, 93.92, 94.14, 94.34];
const count = (ts: number[], t: number) => ts.filter((x) => t >= x).length;

export const Main: React.FC<{ hq?: boolean }> = ({ hq = false }) => {
  const frame = useCurrentFrame();
  const { fps, width, height } = useVideoConfig();
  const t = frame / fps;
  const a = useAssets(hq);

  const geo = useMemo(() => {
    if (!a) return null;
    const route = new THREE.CatmullRomCurve3(WAY.map(([lo, la]) => new THREE.Vector3(...world(lo, la, CRUISE))));
    const crashAlt = heightAt(...CRASH) + 40;
    const end = WAY[WAY.length - 1];
    const descent = new THREE.CatmullRomCurve3([
      new THREE.Vector3(...world(end[0], end[1], CRUISE)),
      new THREE.Vector3(...world(-69.6, -33.346, 6950)),
      new THREE.Vector3(...world(CRASH[0], CRASH[1], crashAlt)),
    ]);
    const believed = new THREE.CatmullRomCurve3([
      new THREE.Vector3(...world(BELIEVED[0][0], BELIEVED[0][1], CRUISE)),
      new THREE.Vector3(...world(BELIEVED[1][0], BELIEVED[1][1], 5600)),
      new THREE.Vector3(...world(BELIEVED[2][0], BELIEVED[2][1], 2400)),
    ]);
    // u lookup by longitude along the route
    const N = 800, xs: number[] = [];
    for (let i = 0; i <= N; i++) xs.push(route.getPointAt(i / N).x);
    const uForLon = (lon: number) => {
      const x = lonLatToXZ(lon, -33.3)[0];
      for (let i = 0; i < N; i++) if ((xs[i] - x) * (xs[i + 1] - x) <= 0) return (i + (x - xs[i]) / (xs[i + 1] - xs[i] || 1)) / N;
      return x < xs[N] ? 1 : 0;
    };
    const tube = (c: THREE.Curve<THREE.Vector3>, seg: number, rs: number[]) => rs.map((r) => new THREE.TubeGeometry(c, seg, r, 8, false));
    // wind streaks
    const r = rng(11);
    const wind = Array.from({ length: 70 }, () => ({ lon: -71 + r() * 3.2, lat: -33.75 + r() * 0.85, alt: 6400 + r() * 2400, ph: r(), len: 0.08 + r() * 0.14 }));
    // avalanche particles
    const r2 = rng(5);
    const snow = Array.from({ length: 420 }, () => ({ a: r2(), b: r2() * 2 - 1, c: r2() }));
    return {
      route, descent, believed, uForLon, crashAlt,
      routeTubes: tube(route, 900, [0.0045, 0.012, 0.028]),
      descTubes: tube(descent, 200, [0.004, 0.011, 0.024]),
      belTubes: tube(believed, 200, [0.004, 0.011, 0.024]),
      wind, snow,
      meshes: { base: makeTerrain(a.base, hq ? 1 : 2), core: makeTerrain(a.core, hq ? 1 : 3, a.base), fine: a.fine ? makeTerrain(a.fine, 1, a.core) : null },
      cloudBox: (() => {
        const [x0, z0] = lonLatToXZ(-71.4, -32.5), [x1, z1] = lonLatToXZ(-68.0, -34.2);
        return { x: (x0 + x1) / 2, z: (z0 + z1) / 2, w: x1 - x0, d: z1 - z0 };
      })(),
    };
  }, [a]);

  if (!a || !geo) return <AbsoluteFill style={{ background: "#0d1a36" }} />;


  // ---- aircraft state ----
  let planePos: THREE.Vector3 | null = null, planeDir = new THREE.Vector3(-1, 0, 0), planeOp = 0, routeU = 0, descU = 0, belU = 0;
  if (t >= 7.0 && t < 41.8) {
    routeU = geo.uForLon(lonAt(PLANE1, t));
    planePos = geo.route.getPointAt(routeU); planeDir = geo.route.getTangentAt(routeU);
    planeOp = Math.min(smooth((t - 7.0) / 0.6), smooth((41.6 - t) / 0.7));
  } else if (t >= 58.4 && t < 74.95) {
    if (t < 70.3) {
      routeU = geo.uForLon(lonAt(PLANE2, t));
      planePos = geo.route.getPointAt(routeU); planeDir = geo.route.getTangentAt(routeU);
    } else {
      descU = Math.pow(clamp01((t - 70.3) / 4.65), 1.35);
      planePos = geo.descent.getPointAt(descU); planeDir = geo.descent.getTangentAt(descU);
      routeU = 1;
    }
    planeOp = smooth((t - 58.4) / 0.8);
  }
  const cam = camAt(t, planePos);
  const pc = new THREE.PerspectiveCamera(FOV, width / height, 0.005, 200);
  pc.position.copy(cam.pos); pc.lookAt(cam.look); pc.updateMatrixWorld(); pc.updateProjectionMatrix();
  const proj = (v: [number, number, number] | THREE.Vector3) => {
    const q = (v instanceof THREE.Vector3 ? v.clone() : new THREE.Vector3(...v)).project(pc);
    return { x: (q.x * 0.5 + 0.5) * width, y: (1 - (q.y * 0.5 + 0.5)) * height, vis: q.z < 1 && q.z > -1 };
  };
  const span = Math.min(0.22, Math.max(0.06, cam.dist * 0.065));
  if (t >= 70.3) belU = Math.pow(clamp01((t - 70.3) / 5.2), 1.2);
  const ghostOp = win(t, 70.6, 76.2, 0.5);
  const ghostPos = geo.believed.getPointAt(Math.max(0.001, belU)), ghostDir = geo.believed.getTangentAt(Math.max(0.001, belU));

  // trail visibility
  const trail1 = t < 41.8 ? routeU : t < 58.4 ? 1 : routeU; // fraction of route drawn
  const routeOp = t < 41.8 ? 1 : t < 46 ? lerp(1, 0.35, smooth((t - 41.2) / 2)) : t < 58.4 ? 0.35 : t < 85 ? 1 : 1 - smooth((t - 85) / 3) * 0.6;
  const routeColor = t >= 58.4 && t < 86 ? "#9fc4ff" : "#eef5ff";
  const descDraw = t >= 70.3 ? descU : 0;
  const descOp = t < 70.3 ? 0 : t < 86 ? 1 : 1 - smooth((t - 86) / 3) * 0.5;

  // fog scales with camera distance
  const fogNear = cam.dist * 1.4 + 0.6, fogFar = cam.dist * 4.8 + 5;
  const cloudOp = win(t, 59.2, 77.5, 1.4) * 0.5;
  const windOp = win(t, 59.6, 75.2, 0.8);
  const crashV = new THREE.Vector3(...world(CRASH[0], CRASH[1], geo.crashAlt));
  const engineV = new THREE.Vector3(...world(ENGINE[0], ENGINE[1]));
  const flash = t >= 74.9 ? Math.max(0, 1 - (t - 74.9) / 0.9) : 0;
  const snowP = smooth((t - 75.3) / 3.2), snowOp = win(t, 75.3, 86.5, 0.6);

  // ---- search rings ----
  const rings = [[-69.3, -33.25, 0], [-68.9, -32.95, 0.33], [-69.9, -33.55, 0.66]].map(([lo, la, ph]) => {
    const k = ((t - 43 + ph * 2.2) / 2.2) % 1;
    return { p: world(lo, la, 7000), r: 0.08 + k * 1.1, o: (1 - k) * win(t, 43.0, 49.6, 0.6) };
  });

  // ---- labels ----
  const P = (lo: number, la: number, alt?: number) => proj(world(lo, la, alt));
  const planeS = planePos ? proj(planePos) : { x: -999, y: -999, vis: false };
  const ghostS = proj(ghostPos);
  const crashS = proj(crashV), engineS = proj(engineV);
  // glacier flow: dashes from crash site to where the engine emerged
  const flowPts = Array.from({ length: 12 }, (_, i) => {
    const s = i / 11;
    const lo = lerp(CRASH[0], ENGINE[0], s), la = lerp(CRASH[1], ENGINE[1], s);
    return proj(world(lo, la, heightAt(lo, la) + 30));
  });
  const flowOp = win(t, 79.6, 88.5, 0.6);
  const wreckS = (() => {
    const s = smooth((t - 80.0) / 4.6);
    const lo = lerp(CRASH[0], ENGINE[0], s), la = lerp(CRASH[1], ENGINE[1], s);
    return proj(world(lo, la, heightAt(lo, la) + 30));
  })();

  // ---- clock ----
  const clock = (() => {
    if (t < 14) return "13:46";
    if (t < 22.8) { const m = Math.round(lerp(15 * 60 + 2, 17 * 60 + 38, smooth((t - 14) / 8.6))); return `${Math.floor(m / 60)}:${String(m % 60).padStart(2, "0")}`; }
    if (t < 38) return "17:41";
    return "17:42";
  })();


  return (
    <AbsoluteFill style={{ background: "#13234a" }}>
      <ThreeCanvas width={width} height={height} camera={{ fov: FOV, near: 0.005, far: 200 }} gl={{ antialias: hq }}>
        <color attach="background" args={["#1a2c55"]} />
        <fog attach="fog" args={["#1d3060", fogNear, fogFar]} />
        <ambientLight intensity={0.9} color="#9fb6e6" />
        <directionalLight position={[-3, 5, -2]} intensity={2.2} color="#e6eeff" />
        <CameraRig cam={cam} />
        <mesh geometry={geo.meshes.base}><meshBasicMaterial map={a.baseTex} /></mesh>
        <mesh geometry={geo.meshes.core} renderOrder={1}>
          <meshBasicMaterial map={a.coreTex} polygonOffset polygonOffsetFactor={-2} polygonOffsetUnits={-8} />
        </mesh>
        {geo.meshes.fine && (
          <mesh geometry={geo.meshes.fine} renderOrder={2}>
            <meshBasicMaterial map={a.fineTex} polygonOffset polygonOffsetFactor={-4} polygonOffsetUnits={-16} />
          </mesh>
        )}

        {/* main route trail */}
        {geo.routeTubes.map((g, i) => {
          g.setDrawRange(0, Math.floor(Math.max(0, trail1 - (planePos && t < 70.3 ? 0.004 : 0)) * 900) * 8 * 6);
          return <mesh key={"r" + i} geometry={g}><meshBasicMaterial color={i === 0 ? routeColor : BLUE} transparent opacity={[0.95, 0.32, 0.1][i] * routeOp} blending={THREE.AdditiveBlending} depthWrite={false} fog={false} /></mesh>;
        })}
        {/* real descent (red) */}
        {descOp > 0 && geo.descTubes.map((g, i) => {
          g.setDrawRange(0, Math.floor(descDraw * 200) * 8 * 6);
          return <mesh key={"d" + i} geometry={g}><meshBasicMaterial color={i === 0 ? "#ffd0c8" : RED} transparent opacity={[0.95, 0.4, 0.14][i] * descOp} blending={THREE.AdditiveBlending} depthWrite={false} fog={false} /></mesh>;
        })}
        {/* believed path (blue ghost) */}
        {ghostOp > 0 && geo.belTubes.map((g, i) => {
          g.setDrawRange(0, Math.floor(belU * 200) * 8 * 6);
          return <mesh key={"b" + i} geometry={g}><meshBasicMaterial color={i === 0 ? "#dbe9ff" : BLUE} transparent opacity={[0.7, 0.28, 0.1][i] * ghostOp} blending={THREE.AdditiveBlending} depthWrite={false} fog={false} /></mesh>;
        })}

        {planePos && <Plane pos={planePos} dir={planeDir} t={t} span={span} op={planeOp} />}
        {planePos && (
          <sprite position={planePos} scale={[span * 1.4, span * 1.4, span * 1.4]}>
            <spriteMaterial map={glowTex} blending={THREE.AdditiveBlending} depthWrite={false} transparent fog={false} opacity={0.35 * planeOp} />
          </sprite>
        )}
        {ghostOp > 0 && (
          <sprite position={ghostPos} scale={[span * 2.2, span * 2.2, 1]}>
            <spriteMaterial map={glowTex} color={BLUE} blending={THREE.AdditiveBlending} depthWrite={false} transparent fog={false} opacity={0.9 * ghostOp} />
          </sprite>
        )}
        {ghostOp > 0 && <Plane pos={ghostPos} dir={ghostDir} t={t} span={span} op={ghostOp} tint={BLUE} ghost />}

        {/* clouds */}
        {cloudOp > 0.01 && (
          <mesh position={[geo.cloudBox.x, metersToY(5900), geo.cloudBox.z]} rotation={[-Math.PI / 2, 0, 0]}>
            <planeGeometry args={[geo.cloudBox.w, geo.cloudBox.d]} />
            <meshBasicMaterial map={(() => { cloudTex.repeat.set(2.2, 1.4); cloudTex.offset.set(-t * 0.012, 0); return cloudTex; })()} transparent opacity={cloudOp} depthWrite={false} />
          </mesh>
        )}
        {/* jet-stream wind streaks, blowing east (against the westbound plane) */}
        {windOp > 0.01 && geo.wind.map((w, i) => {
          const k = (w.ph + t * 0.16) % 1;
          const [x, , z] = world(lerp(-71, -67.8, k), w.lat, w.alt);
          const fade = Math.sin(k * Math.PI);
          return (
            <mesh key={"w" + i} position={[x, metersToY(w.alt), z]}>
              <boxGeometry args={[w.len, 0.0018, 0.0018]} />
              <meshBasicMaterial color="#cfe2ff" transparent opacity={0.4 * fade * windOp} blending={THREE.AdditiveBlending} depthWrite={false} fog={false} />
            </mesh>
          );
        })}
        {/* search rings */}
        {rings.map((g, i) => g.o > 0.01 && (
          <mesh key={"s" + i} position={g.p} rotation={[-Math.PI / 2, 0, 0]} scale={[g.r, g.r, g.r]}>
            <ringGeometry args={[0.96, 1, 96]} />
            <meshBasicMaterial color={AMBER} transparent opacity={0.8 * g.o} blending={THREE.AdditiveBlending} depthWrite={false} fog={false} side={THREE.DoubleSide} />
          </mesh>
        ))}
        {/* impact flash */}
        {flash > 0 && (
          <sprite position={crashV} scale={[0.5 * (1.2 - flash) + 0.1, 0.5 * (1.2 - flash) + 0.1, 1]}>
            <spriteMaterial map={glowTex} color="#ffd9b0" blending={THREE.AdditiveBlending} depthWrite={false} transparent fog={false} opacity={flash} />
          </sprite>
        )}
        {/* avalanche: snow spilling down from the impact point */}
        {snowOp > 0.01 && (() => {
          // a soft cloud of snow sliding from the impact point toward the lower glacier
          const pos = new Float32Array(geo.snow.length * 3);
          geo.snow.forEach((s, i) => {
            const d = (0.1 + s.a * 0.9) * snowP;
            const side = s.b * 0.004 * (0.4 + d);
            const lo = lerp(CRASH[0], ENGINE[0] + 0.01, d) + side * 0.3;
            const la = lerp(CRASH[1], ENGINE[1] - 0.003, d) + side;
            const [x, y, z] = world(lo, la, heightAt(lo, la) + 20 + s.c * 70);
            pos.set([x, y, z], i * 3);
          });
          const g = new THREE.BufferGeometry();
          g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
          return (
            <points geometry={g}>
              <pointsMaterial map={glowTex} color="#f2f6ff" size={0.012} sizeAttenuation transparent opacity={0.85 * snowOp} depthWrite={false} depthTest={false} blending={THREE.AdditiveBlending} fog={false} />
            </points>
          );
        })()}
      </ThreeCanvas>

      {/* screen-space grading */}
      <AbsoluteFill style={{ background: "linear-gradient(#0b1530 0%, rgba(11,21,48,.35) 14%, rgba(11,21,48,0) 26%, rgba(11,21,48,0) 78%, rgba(11,21,48,.7) 100%)" }} />
      <AbsoluteFill style={{ background: "linear-gradient(rgba(8,16,38,0) 60%, rgba(8,16,38,.72) 66.5%, rgba(8,16,38,.72) 76%, rgba(8,16,38,0) 82%)" }} />
      {flash > 0 && <AbsoluteFill style={{ background: "#ffe6cc", opacity: flash * 0.35 }} />}
      {t > 40.9 && t < 42.6 && <AbsoluteFill style={{ background: "#000", opacity: win(t, 40.9, 42.6, 0.5) * 0.35 }} />}

      {/* glacier flow (SVG dashes) */}
      {flowOp > 0.01 && (
        <svg width={width} height={height} style={{ position: "absolute", left: 0, top: 0, opacity: flowOp }}>
          <polyline points={flowPts.map((p) => `${p.x},${p.y}`).join(" ")} fill="none" stroke="#bfe0ff" strokeWidth={4} strokeDasharray="14 12" strokeDashoffset={-t * 40} strokeLinecap="round" />
          <circle cx={wreckS.x} cy={wreckS.y} r={11} fill={RED} style={{ filter: `drop-shadow(0 0 10px ${RED})` }} />
        </svg>
      )}
      {/* search beam / pins */}
      {(() => {
        const o = win(t, 52.6, 58.4, 0.5) + win(t, 84.4, 92.0, 0.5);
        if (o <= 0.01 || !engineS.vis) return null;
        return (
          <div style={{ position: "absolute", left: engineS.x - 2, top: engineS.y - 170, width: 4, height: 170, background: `linear-gradient(rgba(255,90,74,0), ${RED})`, opacity: o * safe(engineS.y) }} />
        );
      })()}

      {/* data strip */}
      <TopLine text="02 AUG 1947" op={win(t, 0.4, 7.2)} />
      <TopLine text={`02 AUG 1947 · ${clock} LOCAL`} op={win(t, 7.4, 40.9)} />
      <TopLine text="17:45 · NO ARRIVAL" op={win(t, 41.2, 46.4)} color={AMBER} />
      <TopLine text="SEARCH · NOTHING FOUND" op={win(t, 46.6, 49.6)} color={AMBER} />
      <TopLine text="MOUNT TUPUNGATO · ARGENTINA" op={win(t, 50.0, 58.2)} />
      <TopLine text="RECONSTRUCTION · 02 AUG 1947" op={win(t, 58.6, 75.6)} />
      <TopLine text="TUPUNGATO GLACIER" op={win(t, 76.0, 85.6)} />
      <TopLine text="STAR DUST · 1947 – 1998" op={win(t, 85.9, DURATION + 1)} />

      {/* top centre stage (one element at a time) */}
      <Stendec shown={count(L1, t)} op={win(t, 2.4, 6.9, 0.4)} />
      <TopLine text="ALTITUDE" op={win(t, 19.6, 22.5, 0.3)} top={232} size={20} />
      <TopLine text={`${(Math.round(lerp(18000, 24000, smooth((t - 20.2) / 1.8)) / 100) * 100).toLocaleString("en-US")} FT`} op={win(t, 19.6, 22.5, 0.3)} top={270} size={64} color="#ffffff" />
      <TopLine text={"ETA SANTIAGO 17.45 HRS".slice(0, Math.floor(clamp01((t - 25.6) / 1.6) * 22))} op={win(t, 25.4, 34.4, 0.3)} top={232} size={24} color={AMBER} />
      <Stendec shown={count(L2, t)} op={win(t, 30.9, 41.0, 0.35)} flash={(t > 38.2 && t < 38.7) || (t > 39.1 && t < 39.6) ? 1 : 0} />
      <TopLine text="SIGNAL LOST" op={win(t, 41.0, 42.9, 0.3)} top={232} size={24} color={RED} />
      <Year y={lerp(1947, 1998, smooth((t - 50.0) / 1.0))} op={win(t, 49.9, 54.6, 0.4)} />
      <Year y={lerp(1947, 1998, smooth((t - 80.0) / 4.6))} op={win(t, 79.8, 85.6, 0.4)} />
      <Stendec shown={count(L3, t)} op={win(t, 92.6, DURATION + 1, 0.35)} suffix={t > 95.0 ? "?" : undefined} />

      {/* map labels */}
      <Label p={P(...BA)} title="BUENOS AIRES" op={win(t, 7.4, 13.6)} color={AMBER} />
      <Label p={P(-68.84, -32.89)} title="MENDOZA" op={win(t, 14.6, 19.4)} />
      <Label p={P(-69.8, -33.358)} title="TUPUNGATO" sub="6,570 M" op={win(t, 17.6, 33.8)} />
      <Label p={P(-70.67, -33.45)} title="SANTIAGO" sub="ETA 17:45" op={win(t, 25.6, 41.0)} color={AMBER} left />
      <Label p={engineS} title="ENGINE FOUND · 1998" sub="~4,600 M ON THE GLACIER" op={win(t, 53.4, 58.3)} color={RED} />
      <Label p={engineS} title="WRECKAGE EMERGES" sub="1998 – 2000" op={win(t, 84.6, 91.5)} color={RED} />
      <Label p={ghostS} title="WHERE THEY THOUGHT" sub="THEY WERE" op={ghostOp * win(t, 71.0, 75.8)} color={BLUE} left />
      <Label p={planeS} title="WHERE THEY" sub="REALLY WERE" op={win(t, 71.0, 74.9, 0.4)} color={RED} />
      <Label p={crashS} title="IMPACT" sub="TUPUNGATO GLACIER" op={win(t, 75.2, 79.4)} color={RED} />
      {/* aircraft tags */}
      {planePos && (() => {
        const tags: [number, number, string, string][] = [
          [8.0, 13.8, "STAR DUST · AVRO LANCASTRIAN", "BUENOS AIRES → SANTIAGO · 11 ON BOARD"],
          [60.4, 68.4, "HEADWIND ◂ JET STREAM", "GROUND SPEED LOWER THAN THEY THOUGHT"],
        ];
        return tags.map(([s, e, a1, b1]) => {
          const o = win(t, s, e) * safe(planeS.y + 50);
          if (o <= 0.01) return null;
          return (
            <div key={a1} style={{ position: "absolute", left: Math.max(50, Math.min(planeS.x - 250, 1080 - 600)), top: planeS.y + 56, opacity: o, fontFamily: MONO, fontSize: 20, letterSpacing: 3,
              color: "#cfe0ff", whiteSpace: "nowrap", textShadow: "0 0 8px rgba(0,0,0,.95), 0 0 2px #000" }}>
              {a1}
              <div style={{ opacity: 0.8, fontSize: 16, marginTop: 4 }}>{b1}</div>
            </div>
          );
        });
      })()}

      <Narration t={t} />
      <Audio src={staticFile("mix.wav")} />
    </AbsoluteFill>
  );
};
