import React, { useEffect, useMemo, useState } from "react";
import { AbsoluteFill, Audio, continueRender, delayRender, staticFile, useCurrentFrame, useVideoConfig, Easing } from "remotion";
import { ThreeCanvas } from "@remotion/three";
import { useThree } from "@react-three/fiber";
import * as THREE from "three";
import { BASE, CORE, EX, UNIT_M, addGrid, boxXZ, frac, sample, world } from "./geo";

const SERIF = "'Cormorant Garamond', serif";
const MONO = "'IBM Plex Mono', monospace";
const AMBER = "#ffb547";
const FOV = 36;
const clamp01 = (x: number) => Math.max(0, Math.min(1, x));
const smooth = (x: number) => { const c = clamp01(x); return c * c * (3 - 2 * c); };
const ease = Easing.bezier(0.4, 0, 0.2, 1);
const win = (t: number, a: number, b: number, d = 0.5) => Math.min(smooth((t - a) / d), smooth((b - t) / d));

// ---------- data ----------
type Grid = { h: Uint16Array; gw: number; gh: number; b: typeof CORE };
type Assets = { base: Grid; core: Grid; baseTex: THREE.Texture; coreTex: THREE.Texture };
const loadTex = (f: string) => new Promise<THREE.Texture>((res) => new THREE.TextureLoader().load(staticFile(f), (t) => {
  t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 16; t.generateMipmaps = true; t.minFilter = THREE.LinearMipmapLinearFilter; res(t);
}));
const useAssets = () => {
  const [h] = useState(() => delayRender("terrain"));
  const [state, set] = useState<Assets | null>(null);
  useEffect(() => {
    Promise.all([
      fetch(staticFile("base_h.bin")).then((r) => r.arrayBuffer()),
      fetch(staticFile("core_h.bin")).then((r) => r.arrayBuffer()),
      loadTex("base_tex.jpg"), loadTex("core_tex.jpg"),
    ]).then(([bh, ch, baseTex, coreTex]) => {
      const base = { h: new Uint16Array(bh), gw: BASE.gw, gh: BASE.gh, b: BASE as typeof CORE };
      const core = { h: new Uint16Array(ch), gw: CORE.gw, gh: CORE.gh, b: CORE };
      addGrid(base); addGrid(core);
      set({ base, core, baseTex, coreTex });
      continueRender(h);
    });
  }, [h]);
  return state;
};

// mesh over a grid's box; `step` subsamples, edges of an inset ease toward the base heights
const makeTerrain = (g: Grid, step: number, base?: Grid) => {
  const { x0, z0, x1, z1 } = boxXZ(g.b);
  const sx = Math.floor(g.gw / step) - 1, sy = Math.floor(g.gh / step) - 1;
  const geo = new THREE.PlaneGeometry(x1 - x0, z1 - z0, sx, sy);
  geo.rotateX(-Math.PI / 2);
  geo.translate((x0 + x1) / 2, 0, (z0 + z1) / 2);
  const pos = geo.attributes.position as THREE.BufferAttribute;
  for (let j = 0; j <= sy; j++) for (let i = 0; i <= sx; i++) {
    const u = i / sx, v = j / sy;
    let m = sample(g, u, v);
    if (base) {
      const lon = g.b.lon0 + (g.b.lon1 - g.b.lon0) * u;
      const merc = (la: number) => Math.log(Math.tan(Math.PI / 4 + (la * Math.PI) / 360));
      const yv = merc(g.b.lat0) + (merc(g.b.lat1) - merc(g.b.lat0)) * v;
      const lat = (2 * Math.atan(Math.exp(yv)) - Math.PI / 2) * 180 / Math.PI;
      const [bu, bv] = frac(base.b, lon, lat);
      const e = clamp01(Math.min(u, 1 - u, v, 1 - v) / 0.06);
      m = m * e + sample(base, bu, bv) * (1 - e);
    }
    pos.setY(j * (sx + 1) + i, (Math.max(m, 0) / UNIT_M) * EX);
  }
  geo.computeVertexNormals();
  return geo;
};

// ---------- the aircraft (stylised Avro Lancastrian: 4 engines, twin fins) ----------
const Plane: React.FC<{ pos: THREE.Vector3; dir: THREE.Vector3; t: number; span: number }> = ({ pos, dir, t, span }) => {
  const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(1, 0, 0), dir.clone().normalize());
  const s = span / 31; // model units in metres, wingspan 31 m
  const metal = <meshStandardMaterial color="#d9dee8" metalness={0.55} roughness={0.35} />;
  const dark = <meshStandardMaterial color="#3a4152" metalness={0.3} roughness={0.6} />;
  const blink = Math.sin(t * 9) > 0.2 ? 1 : 0.15;
  return (
    <group position={pos} quaternion={q} scale={[s, s, s]}>
      {/* fuselage */}
      <mesh rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[1.25, 0.8, 21, 18]} />{metal}</mesh>
      <mesh position={[11.2, 0, 0]} rotation={[0, 0, -Math.PI / 2]}><coneGeometry args={[1.25, 3.2, 18]} />{metal}</mesh>
      <mesh position={[9.4, 0.75, 0]}><boxGeometry args={[2.0, 0.6, 1.6]} />{dark}</mesh>
      {/* wings */}
      <mesh position={[1.6, -0.3, 0]}><boxGeometry args={[4.2, 0.45, 31]} />{metal}</mesh>
      {/* engines */}
      {[-10.5, -4.6, 4.6, 10.5].map((z) => (
        <group key={z} position={[3.3, -0.35, z]}>
          <mesh rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.75, 0.6, 5.2, 14]} />{metal}</mesh>
          <mesh position={[2.75, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
            <circleGeometry args={[2.2, 24]} />
            <meshBasicMaterial color="#cfd8ea" transparent opacity={0.18} side={THREE.DoubleSide} depthWrite={false} />
          </mesh>
        </group>
      ))}
      {/* tail: tailplane + twin fins */}
      <mesh position={[-9.6, 0.2, 0]}><boxGeometry args={[2.6, 0.3, 10]} />{metal}</mesh>
      {[-5, 5].map((z) => <mesh key={z} position={[-9.8, 1.4, z]}><boxGeometry args={[2.4, 3.2, 0.3]} />{metal}</mesh>)}
      {/* navigation lights */}
      <mesh position={[1.6, -0.2, -15.6]}><sphereGeometry args={[0.6, 8, 8]} /><meshBasicMaterial color="#ff3b3b" /></mesh>
      <mesh position={[1.6, -0.2, 15.6]}><sphereGeometry args={[0.6, 8, 8]} /><meshBasicMaterial color="#3bff7a" /></mesh>
      <mesh position={[-10.8, 0.4, 0]}><sphereGeometry args={[0.5, 8, 8]} /><meshBasicMaterial color="#ffffff" transparent opacity={blink} /></mesh>
    </group>
  );
};

// ---------- flight path ----------
const CRUISE = 7300;
const WAY: [number, number][] = [[-67.0, -33.08], [-68.0, -33.18], [-69.0, -33.3], [-69.77, -33.36], [-70.8, -33.42]];
const glowTex = (() => {
  const c = document.createElement("canvas"); c.width = c.height = 128;
  const x = c.getContext("2d")!; const g = x.createRadialGradient(64, 64, 0, 64, 64, 64);
  g.addColorStop(0, "rgba(255,255,255,.9)"); g.addColorStop(0.3, "rgba(160,200,255,.35)"); g.addColorStop(1, "rgba(80,140,255,0)");
  x.fillStyle = g; x.fillRect(0, 0, 128, 128);
  return new THREE.CanvasTexture(c);
})();
const progressAt = (t: number) => 0.02 + ease(clamp01((t - 0.2) / 9.6)) * 0.66;

const CameraRig: React.FC<{ cam: { pos: THREE.Vector3; look: THREE.Vector3 } }> = ({ cam }) => {
  const { camera } = useThree();
  camera.position.copy(cam.pos);
  camera.lookAt(cam.look);
  (camera as THREE.PerspectiveCamera).fov = FOV;
  (camera as THREE.PerspectiveCamera).updateProjectionMatrix();
  return null;
};
const TUPU = new THREE.Vector3();
const camFor = (t: number, head: THREE.Vector3) => {
  const p = ease(clamp01(t / 10));
  const fwd = TUPU.clone().sub(head); fwd.y = 0; fwd.normalize();
  const target = head.clone().add(fwd.multiplyScalar(THREE.MathUtils.lerp(0.05, 0.2, p)));
  target.y = THREE.MathUtils.lerp(0.2, 0.15, p);
  const dist = THREE.MathUtils.lerp(4.2, 2.6, p);
  const pitch = THREE.MathUtils.degToRad(THREE.MathUtils.lerp(48, 30, p));
  const yaw = THREE.MathUtils.degToRad(THREE.MathUtils.lerp(118, 140, p)); // 90 = camera due east looking west
  const pos = new THREE.Vector3(target.x + Math.sin(yaw) * Math.cos(pitch) * dist, target.y + Math.sin(pitch) * dist, target.z + Math.cos(yaw) * Math.cos(pitch) * dist);
  return { pos, look: target };
};

// ---------- overlay ----------
const safe = (y: number) => Math.min(smooth((y - 560) / 60), smooth((1160 - y) / 60));
const Label: React.FC<{ x: number; y: number; title: string; sub?: string; op: number; color?: string }> = ({ x, y, title, sub, op, color = "#dbe7ff" }) => (
  <div style={{ position: "absolute", left: Math.min(x, 820), top: y, opacity: op * safe(y), transform: "translate(-6px,-6px)" }}>
    <div style={{ width: 12, height: 12, borderRadius: 6, background: color, boxShadow: `0 0 14px ${color}` }} />
    <div style={{ position: "absolute", left: 22, top: -6, whiteSpace: "nowrap", fontFamily: MONO, fontWeight: 500, fontSize: 22, letterSpacing: 4, color, textShadow: "0 0 8px rgba(0,0,0,.9), 0 0 2px #000" }}>
      {title}
      {sub && <div style={{ fontSize: 17, letterSpacing: 2, opacity: 0.8, marginTop: 4 }}>{sub}</div>}
    </div>
  </div>
);
const MORSE: Record<string, string> = { S: "···", T: "−", E: "·", N: "−·", D: "−··", C: "−·−·" };

export const Test3D: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps, width, height } = useVideoConfig();
  const t = frame / fps;
  const a = useAssets();

  const curve = useMemo(() => (a ? new THREE.CatmullRomCurve3(WAY.map(([lo, la]) => new THREE.Vector3(...world(lo, la, CRUISE)))) : null), [a]);
  const meshes = useMemo(() => (a ? { base: makeTerrain(a.base, 1), core: makeTerrain(a.core, 2, a.base) } : null), [a]);
  const tubes = useMemo(() => (curve ? [0.0045, 0.012, 0.028].map((r) => new THREE.TubeGeometry(curve, 600, r, 10, false)) : null), [curve]);

  if (!a || !curve || !meshes || !tubes) return <AbsoluteFill style={{ background: "#0d1a36" }} />;

  TUPU.set(...world(-69.77, -33.36));
  const p = progressAt(t);
  const head = curve.getPointAt(p);
  const dir = curve.getTangentAt(p);
  const cam = camFor(t, head);
  const trail = Math.floor(Math.max(0, p - 0.012) * 600) * 10 * 6; // line stops just behind the aircraft

  const pc = new THREE.PerspectiveCamera(FOV, width / height, 0.01, 200);
  pc.position.copy(cam.pos); pc.lookAt(cam.look); pc.updateMatrixWorld(); pc.updateProjectionMatrix();
  const proj = (v: [number, number, number] | THREE.Vector3) => {
    const q = (v instanceof THREE.Vector3 ? v.clone() : new THREE.Vector3(...v)).project(pc);
    return { x: (q.x * 0.5 + 0.5) * width, y: (1 - (q.y * 0.5 + 0.5)) * height, vis: q.z < 1 };
  };
  const mendoza = proj(world(-68.84, -32.89));
  const santiago = proj(world(-70.67, -33.45));
  const tupu = proj(world(-69.77, -33.36));
  const planeS = proj(head);
  const letters = "STENDEC".split("");
  const shown = Math.floor(clamp01((t - 6.3) / 2.4) * letters.length + 0.0001);

  return (
    <AbsoluteFill style={{ background: "#13234a" }}>
      <ThreeCanvas width={width} height={height} camera={{ fov: FOV, near: 0.005, far: 200 }}>
        <color attach="background" args={["#1a2c55"]} />
        <fog attach="fog" args={["#1d3060", 7, 20]} />
        <ambientLight intensity={0.9} color="#9fb6e6" />
        <directionalLight position={[-3, 5, -2]} intensity={2.2} color="#e6eeff" />
        <CameraRig cam={cam} />
        <mesh geometry={meshes.base}><meshBasicMaterial map={a.baseTex} /></mesh>
        <mesh geometry={meshes.core} renderOrder={1}>
          <meshBasicMaterial map={a.coreTex} polygonOffset polygonOffsetFactor={-2} polygonOffsetUnits={-8} />
        </mesh>
        {tubes.map((g, i) => {
          g.setDrawRange(0, trail);
          return (
            <mesh key={i} geometry={g}>
              <meshBasicMaterial color={i === 0 ? "#eef5ff" : "#79b2ff"} transparent opacity={[0.95, 0.32, 0.1][i]} blending={THREE.AdditiveBlending} depthWrite={false} fog={false} />
            </mesh>
          );
        })}
        <Plane pos={head} dir={dir} t={t} span={0.17} />
        <sprite position={head} scale={[0.22, 0.22, 0.22]}>
          <spriteMaterial map={glowTex} blending={THREE.AdditiveBlending} depthWrite={false} transparent fog={false} opacity={0.35} />
        </sprite>
      </ThreeCanvas>

      <AbsoluteFill style={{ background: "linear-gradient(#0b1530 0%, rgba(11,21,48,0) 16%, rgba(11,21,48,0) 80%, rgba(11,21,48,.7) 100%)" }} />
      <AbsoluteFill style={{ background: "linear-gradient(rgba(8,16,38,0) 60%, rgba(8,16,38,.7) 66.5%, rgba(8,16,38,.7) 75%, rgba(8,16,38,0) 81%)" }} />
      <Audio src={staticFile("sfx.wav")} />

      <Label x={mendoza.x} y={mendoza.y} title="MENDOZA" op={win(t, 0.8, 7.0) * (mendoza.vis ? 1 : 0)} />
      <Label x={tupu.x} y={tupu.y} title="TUPUNGATO" sub="6,570 M" op={win(t, 3.6, 10.5) * (tupu.vis ? 1 : 0)} />
      <Label x={santiago.x} y={santiago.y} title="SANTIAGO" sub="ETA 17:45" op={win(t, 5.0, 10.5) * (santiago.vis ? 1 : 0)} color={AMBER} />
      <div style={{ position: "absolute", left: Math.min(planeS.x + 40, 640), top: planeS.y + 40, opacity: win(t, 0.6, 5.4) * safe(planeS.y + 50), fontFamily: MONO, fontSize: 19, letterSpacing: 3,
        color: "#cfe0ff", whiteSpace: "nowrap", textShadow: "0 0 8px rgba(0,0,0,.95), 0 0 2px #000" }}>
        STAR DUST · AVRO LANCASTRIAN
        <div style={{ opacity: 0.8, fontSize: 16, marginTop: 4 }}>BUENOS AIRES → SANTIAGO · 11 ON BOARD</div>
      </div>

      <div style={{ position: "absolute", top: 150, left: 0, right: 0, textAlign: "center", fontFamily: MONO, fontSize: 20, letterSpacing: 6, color: "#a8c2ee", opacity: win(t, 0.2, 10.5) }}>
        02 AUG 1947 · {t < 6.3 ? "17:3" + Math.min(9, 6 + Math.floor(t / 2)) : "17:41"} LOCAL
      </div>
      {[["In 1947, a plane flew toward ", "the Andes.", 0.3, 5.4], ["Then it sent ", "one last word.", 5.6, 10.5]].map(([a1, b1, s0, s1]) => (
        <div key={a1 as string} style={{ position: "absolute", top: 1295, left: 90, right: 90, textAlign: "center", fontFamily: SERIF, fontWeight: 600, fontSize: 58, lineHeight: 1.15, color: "#f4f6fb",
          textShadow: "0 2px 16px rgba(0,0,0,.7)", opacity: win(t, s0 as number, s1 as number, 0.6) }}>
          {a1}<span style={{ color: AMBER, fontStyle: "italic" }}>{b1}</span>
        </div>
      ))}
      {t > 6.3 && (
        <div style={{ position: "absolute", top: 300, left: 0, right: 0, display: "flex", justifyContent: "center", gap: 26, opacity: win(t, 6.3, 10.5, 0.3) }}>
          {letters.map((L, i) => (
            <div key={i} style={{ textAlign: "center", opacity: i < shown ? 1 : i === shown ? 0.35 : 0.08 }}>
              <div style={{ fontFamily: MONO, fontSize: 22, color: AMBER, letterSpacing: 2, height: 28 }}>{MORSE[L]}</div>
              <div style={{ fontFamily: SERIF, fontWeight: 600, fontSize: 92, color: i < shown ? "#fff" : "#9fb3d8", textShadow: i < shown ? `0 0 22px ${AMBER}` : "none" }}>{L}</div>
            </div>
          ))}
        </div>
      )}
    </AbsoluteFill>
  );
};
