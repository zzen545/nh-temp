import { Config } from "@remotion/cli/config";
Config.setVideoImageFormat("jpeg");
Config.setOverwriteOutput(true);
if (process.platform === "linux") {
  // cloud container: CPU rendering
  Config.setChromiumOpenGlRenderer("swangle");
  Config.setBrowserExecutable("/opt/pw-browsers/chromium_headless_shell-1243/chrome-headless-shell-linux64/chrome-headless-shell");
} else {
  // Windows PC: GPU rendering via ANGLE (Direct3D)
  Config.setChromiumOpenGlRenderer("angle");
}
